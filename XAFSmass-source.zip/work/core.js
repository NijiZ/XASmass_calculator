/* XAFSmass web port. Original algorithms: Konstantin Klementiev, Roman Chernikov (MIT).
   Tables are copied losslessly from the upstream NPZ data. */
'use strict';
const CROSS=4.208e7, RGAS=8.314510, TEMP=295, SIE0=1.602176565e-19;
function parseFormula(text, reconstruct=true) {
  const s=text.replace(/\s+/g,''); let pos=0;
  if (!s || s.length>2000) throw Error('请输入有效化学式（最长 2000 字符）。');
  function group(depth=0){
    if(depth>30) throw Error('化学式括号嵌套过深。');
    const parts=[];
    while(pos<s.length && s[pos]!==')'){
      let rows;
      if(s[pos]==='('){pos++;rows=group(depth+1);if(s[pos++]!==')')throw Error('化学式括号不匹配。');}
      else {const m=s.slice(pos).match(/^[A-Z][a-z]?/);if(!m || !Object.hasOwn(DATA.masses,m[0]))throw Error('无法识别第 '+(pos+1)+' 位的元素或字符。');pos+=m[0].length;rows=[[m[0],1]];}
      let percent=null, mult=1;
      if(s[pos]==='x'){mult=-1;pos++;if(rows.length!==1 || rows[0][1]!==1)throw Error('x 只能标注一个元素，例如 FexSiO2。');}
      else {
        if(s[pos]==='%'){percent=0;pos++;}
        const m=s.slice(pos).match(/^(?:\d+(?:\.\d*)?|\.\d+)/);
        if(m){pos+=m[0].length;if(percent!==null)percent=Number(m[0]);else mult=Number(m[0]);}
        else if(percent!==null)throw Error('% 后需要填写质量百分数。');
      }
      if(percent!==null && (!(percent>0)||percent>=100))throw Error('质量百分数必须大于 0 且小于 100；纯组分请留空比例。');
      parts.push({rows:rows.map(([e,n])=>[e,n*mult]),percent});
    }
    if(!parts.length)throw Error('化学式或括号内容不能为空。');
    const wt=parts.reduce((a,p)=>a+(p.percent||0),0);
    if(wt>=100)throw Error('同一层级质量百分数之和必须小于 100。');
    const mass=rows=>rows.reduce((a,[e,n])=>a+DATA.atomic[e]*n,0);
    const base=parts.filter(p=>p.percent===null).reduce((a,p)=>a+mass(p.rows),0);
    if(wt && (!(base>0)||parts.some(p=>p.rows.some(r=>r[1]<0))))throw Error('wt% 配方需要正质量的基体，且不能同时使用 x。');
    return parts.flatMap(p=>p.percent===null?p.rows:p.rows.map(([e,n])=>[e,n*base*p.percent/(100-wt)/mass(p.rows)]));
  }
  let rows=group();if(pos!==s.length)throw Error('化学式括号不匹配。');
  // The uploaded Qt GUI reconstructs wt% coefficients to three significant digits.
  if(reconstruct && s.includes('%')) rows=rows.map(([e,n])=>[e,Number.isInteger(n)?n:Number(n.toPrecision(3))]);
  if(rows.some(r=>!Number.isFinite(r[1])))throw Error('化学式数值超出范围。');
  return rows;
}
function tableElement(name,table){
  const t=DATA.tables[table.split(' ')[0]], E=t[name+'_E'], f2=t[name+(table.endsWith('total')?'_f2tot':'_f2')];
  if(!E||!f2||E.length<2||f2.length!==E.length)throw Error(`${table} 中没有 ${name} 的数据，请更换数据表。`);
  return {name,E,f1:t[name+'_f1'],f2,mass:DATA.masses[name],Z:DATA.elements[name].Z};
}
function interp(E,x,y){
  if(E<x[0]||E>x[x.length-1])throw Error(`能量 ${E} eV 超出数据范围 ${x[0]}–${x[x.length-1]} eV，请更换数据表。`);
  let lo=0,hi=x.length-1;while(lo<hi){let m=(lo+hi+1)>>1;if(x[m]<=E)lo=m;else hi=m-1;}
  if(lo===x.length-1)return y[lo];return y[lo]+(y[lo+1]-y[lo])*(E-x[lo])/(x[lo+1]-x[lo]);
}
function edgeStep(E,el){
  let back=250,forward=50,post=0,edge=0,step=0,delta=0,jump=0,sigmaX=0,aux=null;
  while(step<50 && post<2 && edge<1){
    const x=[],y=[];for(let i=0;i<el.E.length;i++)if(E-back<el.E[i]&&el.E[i]<E+forward){x.push(el.E[i]);y.push(el.f2[i]);}
    const rises=[],falls=[];for(let i=0;i<y.length-1;i++){if(y[i+1]>y[i])rises.push(i);if(y[i+1]<y[i])falls.push(i);}
    if(rises.length){
      post=rises[rises.length-1]+1;
      if(post<2){back+=50;step++;continue;}
      const pre=falls.filter(i=>i<post);edge=pre.length?pre[pre.length-1]+1:post-1;
      const k=(y[edge]-y[edge-1])/(x[edge]-x[edge-1]);
      const b=-(y[edge]*x[edge-1]-y[edge-1]*x[edge])/(x[edge]-x[edge-1]);
      const background=k*x[post]+b;jump=y[post]-background;
      delta=jump*CROSS/x[post];sigmaX=y[post]*CROSS/x[post];
      aux={e1:x[edge-1],e2:x[post],y1:y[edge-1],y20:background,y21:y[post]};
    }
    forward+=50;step++;
  }
  return {delta,jump,sigmaX,aux:jump>0?aux:null};
}
function elementDict(rows,E,table){
  const elements=[];let sigma=0,mass=0;
  for(const [name,n] of rows){
    let e=elements.find(v=>v.name===name);
    if(!e){const el=tableElement(name,table), f2=interp(E,el.E,el.f2),edge=edgeStep(E,el);e={...edge,name,el,f2,sigma:edge.sigmaX>0?edge.sigmaX:f2*CROSS/E,n:0};elements.push(e);}
    e.n+=n;if(n>0){sigma+=e.sigma*n;mass+=e.el.mass*n;}
  }
  elements.sort((a,b)=>a.el.Z-b.el.Z);return {elements,sigma,mass};
}
function positive(v,name){if(!Number.isFinite(v)||v<=0)throw Error(name+'必须是大于 0 的数值。');return v;}
function calculate(p){
  const rows=parseFormula(p.formula);positive(p.energy,'能量');positive(p.amount,'吸收参数');positive(p.size,'面积 / 密度 / 长度 / 边跃');
  const xs=rows.filter(r=>r[1]<0);
  if(p.mode==='x' && (xs.length!==1||xs[0][1]!==-1))throw Error('未知含量模式需要且只能有一个 x，例如 FexSiO2。');
  if(p.mode!=='x'&&xs.length)throw Error('当前模式不能含 x，请选择未知含量模式。');
  const d=elementDict(rows,p.energy,p.table),r={...d,rows,mode:p.mode,formula:p.formula,energy:p.energy,table:p.table};
  if(!(d.sigma>0))throw Error('总吸收系数必须大于零。');
  if(p.mode==='powder'||p.mode==='foil'){
    r.nu=p.amount*(p.mode==='powder'?p.size:1)/d.sigma;
    r.massMg=r.nu*d.mass*1000;
    const rho=p.mode==='foil'?p.size:p.rho;
    if(rho!==null&&rho!==undefined)positive(rho,'密度');
    r.thickness=rho?p.amount*d.mass/d.sigma/rho*1e4:null;
    r.elements.forEach(e=>{e.massMg=r.nu*e.el.mass*e.n*1000;e.wt=e.el.mass*e.n/d.mass*100;e.step=p.amount/d.sigma*e.delta*e.n;});
  }else if(p.mode==='gas'){
    if(p.amount>=1)throw Error('气体吸收比例应介于 0 和 1 之间。');
    r.pressure=-Math.log(1-p.amount)/d.sigma*RGAS*TEMP/p.size*1e4;
    r.attenuation=p.amount;
    const groups=rows.map(([e,n])=>[e==='N'?'N2':e,r.pressure*n/(e==='N'?2:1)]);
    r.flux=gasFlux(groups,p.energy,p.size,p.table);
  }else {
    if(p.size>=p.amount)throw Error('边跃 Δμd 必须小于总吸收 μₜd。');
    const e=d.elements.find(e=>e.n===-1),ratio=p.size/p.amount,den=e.delta-ratio*e.sigma;
    if(!(e.delta>0)||!(den>0))throw Error('该能量下未找到可用吸收边，或目标边跃超出可达范围。请检查能量及参数。');
    r.x=ratio*d.sigma/den;
    // Correct the upstream denominator's accidental use of the final loop element.
    r.wt=e.el.mass*r.x/(d.mass+r.x*e.el.mass)*100;
    if(!Number.isFinite(p.uncertainty)||p.uncertainty<0)throw Error('δμd 必须为非负数。');
    r.wtError=Math.abs((p.amount-p.size)/p.amount**2*p.uncertainty*r.wt);
    r.xElement=e.name;
  }
  return r;
}
function gasFlux(mix,E,length,table){
  const pair={He:41,N2:36,N:36,Ne:36.3,Ar:26,Kr:24,Xe:22};let sum=0;
  for(const [gas,p] of mix){if(p===0)continue;if(!pair[gas])return null;const d=elementDict(parseFormula(gas==='N'?'N2':gas),E,table);sum+=(1-Math.exp(-p*length/(RGAS*TEMP*1e4)*d.sigma))/pair[gas];}
  return sum>0?1e-6/(sum*E*SIE0):null;
}
function calculateMixer(mix,E,length,table){
  positive(E,'能量');positive(length,'气室长度');let optical=0,pressure=0;
  for(const [gas,p] of mix){if(!Number.isFinite(p)||p<0)throw Error('分压必须为非负数。');const d=elementDict(parseFormula(gas),E,table);optical+=p*length/(RGAS*TEMP*1e4)*d.sigma;pressure+=p;}
  return {pressure,attenuation:1-Math.exp(-optical),flux:gasFlux(mix,E,length,table)};
}
