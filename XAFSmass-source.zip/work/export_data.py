import sys,json,pathlib,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'pydeps'),str(ROOT/'XAFSmass-master')]
from XAFSmass import materials_simple as rm
import numpy as np
d={'masses':rm.elementsMass,'atomic':{s:rm.read_atomic_data(s) for s in rm.elementsList[1:]},'elements':rm.elemental,'compounds':rm.compounds,'tables':{},'edges':{}}
for table in ['Henke','BrCo','Chantler']:
    with np.load(ROOT/'XAFSmass-master'/'XAFSmass'/'data'/(table+'.npz')) as data:
        d['tables'][table]={k:data[k].astype(float).tolist() for k in data.files}
for line in (ROOT/'XAFSmass-master'/'XAFSmass'/'data'/'Energies.txt').read_text().splitlines()[2:]:
    t=line.split()
    if len(t)>2:
        d['edges'][t[1]]=[float(v) if v not in ('None','-') else None for v in t[2:]]
(ROOT/'data.json').write_text(json.dumps(d,separators=(',',':'),allow_nan=False),encoding='utf-8')
print('data bytes', (ROOT/'data.json').stat().st_size)
