import pathlib,json,hashlib,html,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT.parent/'outputs'
OUT.mkdir(exist_ok=True)
page=(ROOT/'page.html').read_text(encoding='utf-8')
for key,path in [('LICENSE',ROOT/'XAFSmass-master'/'LICENSE'),('DATA',ROOT/'data.json'),('CORE',ROOT/'core.js'),('UI',ROOT/'ui.js')]:
    value=path.read_text(encoding='utf-8')
    if key=='LICENSE':value=html.escape(value)
    page=page.replace('__'+key+'__',value)
(OUT/'XAFSmass.html').write_text(page,encoding='utf-8')
print('HTML bytes:',(OUT/'XAFSmass.html').stat().st_size)
