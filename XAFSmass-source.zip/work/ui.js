const $=id=>document.getElementById(id), fmt=(v,n=6)=>v==null?'—':Number(v.toPrecision(n)).toString();
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let current=null,plotState=null,mixNames=[],mixValues=[];
const modes={powder:{eq:'m = μₜd · S · M / Σ(Nᵢσᵢ)',amount:'总吸收 μₜd',size:'面积 S / cm²',values:[1.5,.3848],ex:'Cu(NO3)2 或 Cu%1Zn%1((Al2O3)%10SiO2)'},foil:{eq:'d = μₜd · M / [ρ · Σ(Nᵢσᵢ)]',amount:'总吸收 μₜd',size:'密度 ρ / g·cm⁻³',values:[1.5,8.96],ex:'Cu 或 Cu%25Zn'},gas:{eq:'p = −ln(1 − att) · RT / [d · Σ(Nᵢσᵢ)]',amount:'吸收比例 att / 0–1',size:'气室长度 d / cm',values:[.5,10],ex:'Ar、N2 或 (Ar)(N2)'},x:{eq:'Δμd / μₜd = NₓΔσₓ / Σ(Nᵢσᵢ)',amount:'总吸收 μₜd',size:'目标边跃 Δμd',values:[1,.1],ex:'FexSiO2 或 CuxSiO2'}};
function option(value,text){const o=document.createElement('option');o.value=value;o.textContent=text;return o;}
Object.entries(DATA.compounds).sort((a,b)=>a[1].rho-b[1].rho).forEach(([k,v])=>$('compounds').append(option(k,`${k} · ${v.rho} g/cm³`)));
Object.keys(DATA.elements).forEach(e=>$('elements').append(option(e,e)));
const edgeNames=['K','L1','L2','L3','M1','M2','M3','M4','M5','N1','N2','N3'];
Object.keys(DATA.edges).filter(e=>DATA.elements[e]).sort((a,b)=>DATA.elements[a].Z-DATA.elements[b].Z).forEach(e=>{
  const o=option(e,`${DATA.elements[e].Z} · ${e} · K ${DATA.edges[e][0]} eV`);o.defaultSelected=e==='Cu';$('edge-element').append(o);
});
function renderEdges(applyEnergy=true){
  const symbol=$('edge-element').value,values=DATA.edges[symbol]||[];
  $('edge-choices').replaceChildren();
  values.forEach((v,i)=>{
    if(!(v>0)||!edgeNames[i])return;
    const label=document.createElement('label');label.className='edge-option';
    const input=document.createElement('input');input.type='radio';input.name='absorption-edge';input.value=edgeNames[i];input.id='edge-'+edgeNames[i];input.dataset.energy=v;
    const text=document.createElement('span');text.textContent=`${edgeNames[i]} · ${v} eV`;
    input.addEventListener('change',()=>{if(input.checked)selectEdge(symbol,edgeNames[i],v);});label.append(input,text);$('edge-choices').append(label);
  });
  const first=$('edge-choices').querySelector('input');
  if(first){first.checked=true;if(applyEnergy)selectEdge(symbol,first.value,Number(first.dataset.energy));else $('edge-note').textContent=`${symbol} ${first.value}：${first.dataset.energy} + 50 = ${$('energy').value} eV`;}
  else $('edge-note').textContent='此元素没有可用的吸收边数据，请手动填写计算能量。';
}
function selectEdge(symbol,edge,value){$('energy').value=Number((value+50).toFixed(6));$('edge-note').textContent=`${symbol} ${edge}：${value} + 50 = ${$('energy').value} eV`;invalidate();setupMixer();}
function invalidate(){current=null;plotState=null;$('results').className='empty';$('results').textContent='输入已更新，请点击计算。';$('export').disabled=true;$('chart-panel').hidden=true;$('error').hidden=true;$('status').textContent='';}
function combine(){const c=$('component').value.trim(),r=$('ratio').value.trim(),m=$('matrix').value.trim();$('combined').value=r?`(${c})%${r}(${m})`:c;try{const rows=parseFormula($('combined').value);const mass=rows.filter(r=>r[1]>0).reduce((a,[e,n])=>a+DATA.atomic[e]*n,0);$('mass-note').textContent=`M ${rows.some(r=>r[1]<0)?'（基体）':''} = ${fmt(mass,5)} g/mol`;}catch(e){$('mass-note').textContent=e.message;}}
function setupMode(resetValues=false){const mode=$('mode').value,info=modes[mode];$('equation').textContent=info.eq;$('amount-label').textContent=info.amount;$('size-label').textContent=info.size;$('example').textContent='示例：'+info.ex;$('rho-field').hidden=mode!=='powder';$('uncertainty-field').hidden=mode!=='x';if(resetValues){$('amount').value=info.values[0];$('size').value=info.values[1];}setupMixer();}
function params(){return {mode:$('mode').value,formula:$('combined').value,component:$('component').value.trim(),ratio:$('ratio').value.trim(),matrix:$('matrix').value.trim(),energy:Number($('energy').value),table:$('table').value,amount:Number($('amount').value),size:Number($('size').value),rho:$('rho').value===''?null:Number($('rho').value),uncertainty:Number($('uncertainty').value)};}
function metric(label,v,unit){return `<div class="metric"><span>${label}</span><strong>${fmt(v)}</strong><small>${unit}</small></div>`;}
function showResult(r){
  const p=params();let metrics='',extra='',head='',body='';
  if(r.mode==='powder'){
    metrics=metric('样品总质量 m',r.massMg,'mg')+'<div class="metric recommendation"><span>压片推荐总质量</span><p><b>7 mm 直径</b> · 推荐 <b>40 mg</b></p><p><b>13 mm 直径</b> · 推荐 <b>90 mg</b></p></div>';
    const fraction=p.ratio===''?1:Number(p.ratio)/100;
    r.componentMassMg=r.massMg*fraction;r.matrixMassMg=r.massMg-r.componentMassMg;
    r.matrixName=p.matrix.replace(/\s+/g,'')==='C6H10O5'?'纤维素（C6H10O5）':p.matrix;
    extra+=`<div class="table-wrap"><table id="preparation"><caption>称量清单</caption><thead><tr><th>材料</th><th>质量 / mg</th></tr></thead><tbody><tr><td>组分：${escapeHTML(p.component)}</td><td class="num" id="component-mass">${fmt(r.componentMassMg)}</td></tr><tr><td>基体：${escapeHTML(r.matrixName)}${p.ratio===''?'（未添加）':''}</td><td class="num" id="matrix-mass">${fmt(r.matrixMassMg)}</td></tr></tbody></table></div><p class="muted">按输入 wt% 分配总质量；比例留空时全部为组分，基体质量为 0。上方推荐质量仅作压片参考。</p>`;
    if(r.thickness!==null)extra+=`<p>厚度 d = <b>${fmt(r.thickness)} μm</b></p>`;
  }
  if(r.mode==='foil'){metrics=metric('厚度 d',r.thickness,'μm')+metric('总吸收 μₜd',p.amount,'无量纲');}
  if(r.mode==='powder'||r.mode==='foil'){
    const selected=r.elements.find(e=>e.name===$('edge-element').value);
    const edgeElement=selected||r.elements.reduce((best,e)=>!best||e.step>best.step?e:best,null);
    if(edgeElement){
      r.edgeStepElement=edgeElement.name;r.edgeStep=edgeElement.step;
      const checked=$('edge-choices').querySelector('input:checked');
      const edgeLabel=selected&&checked?` ${checked.value}`:'';
      extra=`<div class="metric" id="edge-step-result" style="margin:0 0 16px"><span>吸收边跃 / Edge Step · ${edgeElement.name}${edgeLabel}</span><strong id="edge-step-value">${fmt(edgeElement.step,6)}</strong><small>Δμd（无量纲）${selected?'':' · 当前配方中边跃最大的元素'}</small></div>${extra}`;
    }
    head='<tr><th>元素</th>'+(r.mode==='powder'?'<th>质量 / mg</th>':'')+'<th>质量占比 / %</th><th>边跃 Δμd</th></tr>';
    body=r.elements.map(e=>`<tr${e.name===r.edgeStepElement?' class="active-element"':''}><td>${e.name}</td>${r.mode==='powder'?`<td class="num">${fmt(e.massMg)}</td>`:''}<td class="num">${fmt(e.wt,5)}</td><td class="num">${fmt(e.step,5)}</td></tr>`).join('');
  }else if(r.mode==='gas'){metrics=metric('所需压力 p',r.pressure,'mbar')+metric('吸收比例',r.attenuation*100,'%');if(r.flux)extra+=`<p>通量估算：<b>${fmt(r.flux,4)}</b> ph/s/μA</p>`;else extra+='<p class="muted">此气体组成不提供电离室通量估算。</p>';}
  else{metrics=metric(`${r.xElement} 原子系数 Nₓ`,r.x,'相对基体化学式')+metric(`${r.xElement} 质量含量`,r.wt,'wt%');if(p.uncertainty)extra+=`<p>误差估计：± ${fmt(r.wtError,4)} wt%</p>`;}
  $('results').className='';$('results').innerHTML=`<p class="muted">${escapeHTML(r.formula)}<br>${fmt(r.energy)} eV · ${escapeHTML(r.table)}</p><div class="result-grid">${metrics}</div>${extra}${head?`<div class="table-wrap"><table id="element-details"><thead>${head}</thead><tbody>${body}</tbody></table></div>`:''}`;
  $('export').disabled=false;$('status').textContent='计算完成 · wt% 输入配方保持不变';
}
function run(){combine();try{const p=params();current=calculate(p);current.inputs={...p};showResult(current);$('error').hidden=true;if(!$('chart-panel').hidden)plot(false);}catch(e){invalidate();$('error').textContent=e.message;$('error').hidden=false;$('status').textContent='请检查输入参数。';}}
$('form').addEventListener('submit',e=>{e.preventDefault();run();});
for(const id of ['component','ratio','matrix','amount','size','energy','rho','uncertainty'])$(id).addEventListener('input',()=>{invalidate();combine();if(['component','ratio','matrix','size','energy'].includes(id))setupMixer();});
$('mode').addEventListener('change',()=>{invalidate();setupMode(true);combine();});
$('table').addEventListener('change',()=>{invalidate();setupMixer();run();});
$('edge-element').addEventListener('change',()=>renderEdges());
$('energy').addEventListener('input',()=>{$('edge-choices').querySelectorAll('input').forEach(r=>r.checked=false);$('edge-note').textContent='手动计算能量；请填写 edge + 50 eV 后的值。';});
function preset(formula,rho){$('component').value=formula;$('ratio').value='';$('rho').value=rho;if($('mode').value==='foil')$('size').value=rho;invalidate();combine();setupMixer();}
$('compounds').addEventListener('change',()=>{const p=DATA.compounds[$('compounds').value];if(p){preset(p.formula,p.rho);$('elements').value='';}});
$('elements').addEventListener('change',()=>{const e=$('elements').value;if(e){preset(e,DATA.elements[e].rho);$('compounds').value='';}});
$('reset-button').addEventListener('click',()=>{$('form').reset();invalidate();renderEdges(false);setupMode();combine();});
$('print').addEventListener('click',()=>window.print());
function download(blob,name){const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('export').addEventListener('click',()=>{if(!current)return;const r=current,rows=[['XAFSmass offline HTML','2026-10-16'],['字段','数值','单位'],...Object.entries(r.inputs).map(([k,v])=>[k,v??'','']),['temperature',295,'K']];for(const [k,u] of [['edgeStepElement','element'],['edgeStep','dimensionless'],['massMg','mg'],['nu','mol'],['thickness','μm'],['pressure','mbar'],['attenuation','fraction'],['flux','ph/s/μA'],['x','coefficient'],['wt','%'],['wtError','%']])if(r[k]!=null)rows.push([k,r[k],u]);if(r.mode==='powder')rows.push(['componentMassMg',r.componentMassMg,'mg'],['matrixName',r.matrixName,''],['matrixMassMg',r.matrixMassMg,'mg']);rows.push([],['元素','原子系数','质量 mg','wt%','边跃 Δμd']);r.elements.forEach(e=>rows.push([e.name,e.n,e.massMg??'',e.wt??'',e.step??'']));const csv=rows.map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');download(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}),'XAFSmass-results.csv');});
function setupMixer(){
  const c=$('component').value.trim(),valid=/^(?:\s*\([^()]+\)\s*){1,5}$/.test(c)&&!$('ratio').value&&$('mode').value==='gas';
  $('mixer-panel').hidden=!valid;if(!valid){mixNames=[];$('mixer-result').textContent='';return;}
  const names=[...c.matchAll(/\(([^()]+)\)/g)].map(m=>m[1]);
  if(JSON.stringify(names)!==JSON.stringify(mixNames)){mixNames=names;mixValues=names.map(()=>1000);$('mixer').replaceChildren();names.forEach((n,i)=>{const div=document.createElement('div');div.className='gas-row';const label=document.createElement('label');label.htmlFor='gas'+i;label.textContent=n;const input=document.createElement('input');input.id='gas'+i;input.type='range';input.min=0;input.max=3000;input.step=1;input.value=1000;const output=document.createElement('output');output.textContent='1000 mbar';input.addEventListener('input',()=>{mixValues[i]=Number(input.value);output.textContent=input.value+' mbar';updateMixer();});div.append(label,input,output);$('mixer').append(div);});}
  updateMixer();
}
function updateMixer(){try{const r=calculateMixer(mixNames.map((n,i)=>[n,mixValues[i]]),Number($('energy').value),Number($('size').value),$('table').value);$('mixer-result').textContent=`混合气体总压 ${fmt(r.pressure)} mbar · 吸收 ${(r.attenuation*100).toFixed(3)}%${r.flux?' · 通量 '+fmt(r.flux,4)+' ph/s/μA':''}`;}catch(e){$('mixer-result').textContent=e.message;}}
const colors=['#2563eb','#d97706','#059669','#9333ea','#dc2626','#0891b2','#57534e','#c026d3'];
function plot(resetRange=true){
  combine();try{positive(Number($('energy').value),'能量');const d=elementDict(parseFormula($('combined').value),Number($('energy').value),$('table').value);plotState={...d,energy:Number($('energy').value)};$('chart-panel').hidden=false;$('plot-error').hidden=true;
  if(resetRange){$('emin').value=Math.max(Math.min(...d.elements.map(e=>e.el.E[0])),plotState.energy*.8)/1000;$('emax').value=Math.min(Math.max(...d.elements.map(e=>e.el.E.at(-1))),plotState.energy*1.2)/1000;}
  draw();}catch(e){$('error').textContent=e.message;$('error').hidden=false;}
}
function draw(){
  if(!plotState)return;const min=Number($('emin').value)*1000,max=Number($('emax').value)*1000;
  if(!Number.isFinite(min)||!Number.isFinite(max)||min<0||max<=min){$('plot-error').textContent='请填写有效的能量范围，上限必须大于下限。';$('plot-error').hidden=false;return;}
  const data=plotState.elements.map(e=>({...e,indices:e.el.E.map((v,i)=>i).filter(i=>e.el.E[i]>=min&&e.el.E[i]<=max)}));
  if(!data.some(e=>e.indices.length>1)){$('plot-error').textContent='这个范围内没有足够的数据点，请扩大范围。';$('plot-error').hidden=false;return;}
  $('plot-error').hidden=true;
  const canvas=$('chart'),w=canvas.clientWidth,h=canvas.clientHeight,dpr=window.devicePixelRatio||1;canvas.width=w*dpr;canvas.height=h*dpr;const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);
  const left=60,right=58,top=28,bottom=48,pw=w-left-right,ph=h-top-bottom,show=$('show-f1').checked;
  let ymax=0,y1min=Infinity,y1max=-Infinity;for(const e of data)for(const i of e.indices){ymax=Math.max(ymax,e.el.f2[i]);if(e.el.f1[i]>-9990){y1min=Math.min(y1min,e.el.f1[i]);y1max=Math.max(y1max,e.el.f1[i]);}}
  ymax=(ymax||1)*1.08;if(y1min===Infinity){y1min=0;y1max=1;}if(y1min===y1max)y1max=y1min+1;
  const xx=e=>left+(e-min)/(max-min)*pw,yy=v=>top+ph-v/ymax*ph,yf=v=>top+ph-(v-y1min)/(y1max-y1min)*ph;
  ctx.font='11px Segoe UI, sans-serif';ctx.lineWidth=1;
  for(let i=0;i<=5;i++){const y=top+ph*i/5,x=left+pw*i/5;ctx.strokeStyle='#e5eaf1';ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(w-right,y);ctx.stroke();ctx.fillStyle='#596779';ctx.textAlign='right';ctx.fillText(fmt(ymax*(1-i/5),3),left-8,y+4);ctx.textAlign='center';ctx.fillText(fmt((min+(max-min)*i/5)/1000,4),x,h-26);if(show){ctx.textAlign='left';ctx.fillText(fmt(y1max-(y1max-y1min)*i/5,3),w-right+7,y+4);}}
  ctx.fillStyle='#243247';ctx.textAlign='left';ctx.fillText('f″',left,15);if(show){ctx.textAlign='right';ctx.fillText('f′',w-right,15);}ctx.textAlign='center';ctx.fillText('能量 / keV',w/2,h-6);
  ctx.save();ctx.beginPath();ctx.rect(left,top,pw,ph);ctx.clip();
  ctx.strokeStyle='#8195af';ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(xx(plotState.energy),top);ctx.lineTo(xx(plotState.energy),top+ph);ctx.stroke();
  data.forEach((e,k)=>{
    function line(values,map,dash,valid){ctx.strokeStyle=colors[k%colors.length];ctx.lineWidth=1.7;ctx.setLineDash(dash);ctx.beginPath();let started=false;for(const i of e.indices){if(!valid(values[i])){started=false;continue;}if(started)ctx.lineTo(xx(e.el.E[i]),map(values[i]));else ctx.moveTo(xx(e.el.E[i]),map(values[i]));started=true;}ctx.stroke();}
    line(e.el.f2,yy,[],v=>Number.isFinite(v));if(show)line(e.el.f1,yf,[5,3],v=>Number.isFinite(v)&&v>-9990);
    if(e.aux){ctx.strokeStyle=colors[k%colors.length];ctx.setLineDash([2,3]);ctx.beginPath();ctx.moveTo(xx(e.aux.e1),yy(e.aux.y1));ctx.lineTo(xx(e.aux.e2),yy(e.aux.y20));ctx.lineTo(xx(e.aux.e2),yy(e.aux.y21));ctx.stroke();}
  });ctx.restore();
  $('legend').innerHTML=data.map((e,i)=>`<span><i style="background:${colors[i%colors.length]}"></i>${e.name} · f″ ${fmt(e.f2,4)}${e.jump>0?' · Δf″ '+fmt(e.jump,4):''}</span>`).join('');
}
$('plot-button').addEventListener('click',()=>plot());$('zoom').addEventListener('click',draw);$('show-f1').addEventListener('change',draw);
$('full-range').addEventListener('click',()=>{if(!plotState)return;$('emin').value=Math.min(...plotState.elements.map(e=>e.el.E[0]))/1000;$('emax').value=Math.max(...plotState.elements.map(e=>e.el.E.at(-1)))/1000;draw();});
$('save-plot').addEventListener('click',()=>$('chart').toBlob(blob=>{if(blob)download(blob,'XAFSmass-scattering-factors.png');}));
window.addEventListener('resize',()=>{if(!$('chart-panel').hidden)draw();});
renderEdges(false);setupMode();combine();run();





