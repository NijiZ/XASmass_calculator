import sys,pathlib,json,warnings
warnings.filterwarnings('ignore')
ROOT=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'pydeps'),str(ROOT/'XAFSmass-master')]
from XAFSmass import XAFSmassCalc as xc
tests=[]
skipped=[]
formulas=[('Cu',9029),('Cu(NO3)2',9029),('Cu%25Zn',9029),('Cu%1Zn%1((Al2O3)%10SiO2)',9029),('(LiNi0.5Co0.2Mn0.3O2)%6(C6H10O5)',8400),('Fe2O3',7200),('LiFePO4',7200),('Ni%1((Al2O3)%10MgO)',8400),('H2O',10000),('Pt',11600),('Fe0.5Fe0.5O',7200)]
for table in ['Henke','BrCo','Chantler','Chantler total']:
  for formula,E in formulas:
    parsed=xc.formula.parse_string(formula,parse_all=True)
    if '%' in formula:parsed=xc.formula.parse_string(xc.reconstruct(parsed),parse_all=True)
    rows=parsed.as_list()
    if any(len(xc.rm.Element(row[0],table).E)<2 for row in rows):
      skipped.append([table,formula,'empty upstream table'])
      continue
    for mode in ['powder','foil']:
      p=dict(mode=mode,formula=formula,energy=E,table=table,amount=1.5,size=.3848 if mode=='powder' else 3.5,rho=3.5,uncertainty=0)
      if mode=='powder':
        nu,mass,th,ed=xc.calculate_powder(rows,E,1.5,.3848,3.5,table)
        expected=dict(nu=nu/1000,massMg=mass,thickness=th)
      else:
        th,ed=xc.calculate_foil(rows,E,1.5,3.5,table)
        expected=dict(thickness=th)
      expected['steps']={k:float(v[-1]) for k,v in ed.items()}
      tests.append(dict(p=p,rows=[[e[0],e[1]] for e in rows],expected=expected))
  for formula,E in [('Ar',10000),('N2',11208),('Xe',35000),('(Ar)(N2)',10000)]:
    if table=='Henke' and E>30000:continue
    p=dict(mode='gas',formula=formula,energy=E,table=table,amount=.5,size=10,rho=None,uncertainty=0)
    rows=xc.formula.parse_string(formula,parse_all=True).as_list()
    tests.append(dict(p=p,rows=[[e[0],e[1]] for e in rows],expected=dict(pressure=float(xc.calculate_gas(rows,E,.5,10,table)))))
  for formula,E in [('CuxSiO2',9200),('FexSiO2',7200),('Al2O3Fex',7200)]:
    p=dict(mode='x',formula=formula,energy=E,table=table,amount=1,size=.1,rho=None,uncertainty=.01)
    rows=xc.formula.parse_string(formula,parse_all=True).as_list()
    d,s,m=xc.calculate_element_dict(rows,E,table)
    el=next(v for v in d.values() if v[3]==-1)
    x=.1*s/(el[2]-.1*el[1]);wt=el[0].mass*x/(m+x*el[0].mass)*100
    tests.append(dict(p=p,rows=[[e[0],e[1]] for e in rows],expected=dict(x=x,wt=wt,wtError=.9*.01*wt)))
mixes=[]
for table in ['Henke','BrCo','Chantler','Chantler total']:
  for mix in [[['N2',1013]],[['Ar',600],['N2',400]],[['He',100],['Ne',200],['Ar',300],['Kr',400],['Xe',500]]]:
    if any(len(xc.rm.Element('N' if g=='N2' else g,table).E)<2 for g,p in mix):
      skipped.append([table,str(mix),'empty upstream table'])
      continue
    E=11208;length=40
    flux,_=xc.calculate_flux(mix,E,length,table)
    optical=sum(p*length/(xc.R*xc.T*1e4)*xc.calculate_element_dict(xc.formula.parse_string(g).as_list(),E,table)[1] for g,p in mix)
    import math
    mixes.append(dict(mix=mix,E=E,length=length,table=table,expected=dict(flux=flux,attenuation=1-math.exp(-optical),pressure=sum(p for g,p in mix))))
(ROOT/'reference.json').write_text(json.dumps(dict(tests=tests,mixes=mixes,skipped=skipped),default=float),encoding='utf-8')
print('Reference cases:',len(tests),'mixer cases:',len(mixes))
