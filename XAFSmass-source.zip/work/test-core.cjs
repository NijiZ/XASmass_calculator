const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={};vm.createContext(ctx);vm.runInContext('const DATA='+fs.readFileSync(__dirname+'/data.json','utf8')+';\n'+fs.readFileSync(__dirname+'/core.js','utf8')+'\nthis.api={calculate,parseFormula,calculateMixer};',ctx);
const refs=JSON.parse(fs.readFileSync(__dirname+'/reference.json','utf8'));let maxRel=0,checks=0;
function close(a,b,label){assert(Number.isFinite(a),`${label}: non-finite ${a}`);const err=Math.abs(a-b)/Math.max(Math.abs(b),1e-15);maxRel=Math.max(maxRel,err);assert(Math.abs(a-b)<=1e-10*Math.max(Math.abs(b),1)+1e-12,`${label}: ${a} != ${b}`);checks++;}
for(const {p,rows,expected} of refs.tests){if(expected.x<0){assert.throws(()=>ctx.api.calculate(p));continue;}const r=ctx.api.calculate(p);assert.equal(r.rows.length,rows.length);rows.forEach(([e,n],i)=>{assert.equal(r.rows[i][0],e);close(r.rows[i][1],n,'parse '+p.formula);});for(const [k,v] of Object.entries(expected)){if(k==='steps'){for(const [el,step] of Object.entries(v))close(r.elements.find(e=>e.name===el).step,step,`${p.table} ${p.formula} ${el} step`);}else close(r[k],v,`${p.table} ${p.formula} ${k}`);}}
for(const m of refs.mixes){const r=ctx.api.calculateMixer(m.mix,m.E,m.length,m.table);for(const [k,v] of Object.entries(m.expected))close(r[k],v,'mixer '+k);}
for(const s of ['', 'Cu(', '(Cu))','Xx2','Cu%100Zn','Cu%60Zn%50O','Cu%Zn','()', 'Cu%0Zn'])assert.throws(()=>ctx.api.parseFormula(s),s);
const base={mode:'powder',formula:'Cu',energy:9029,table:'Chantler total',amount:1.5,size:.3848,rho:null,uncertainty:0};
for(const change of [{energy:0},{energy:1e10},{amount:0},{size:-1},{rho:0},{formula:'CuxSiO2'},{mode:'gas',amount:1},{mode:'x',formula:'FexCuxSiO2'},{mode:'x',formula:'Cu',size:.1},{mode:'x',formula:'FexSiO2',energy:100,size:.1}])assert.throws(()=>ctx.api.calculate({...base,...change}));
const report={cases:refs.tests.length,mixerCases:refs.mixes.length,numericChecks:checks,maxRelativeError:maxRel,invalidInputs:19};fs.writeFileSync(__dirname+'/test-results.json',JSON.stringify(report,null,2));console.log(report);

