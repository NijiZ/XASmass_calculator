# XAFSmass HTML source

This archive preserves the layout `work/` and `outputs/` used by the build.

## Build

Install Python 3 with numpy and pyparsing, and Node.js for regression tests.

```sh
python -m pip install numpy pyparsing
python work/export_data.py
python work/build.py
python work/reference.py
node work/test-core.cjs
```

The artifact is `outputs/XAFSmass.html`. No runtime packages are required to use it.

`work/page.html` contains the template and theme. `work/ui.js` contains interaction and plotting. `work/core.js` contains the numerical port. `work/export_data.py` converts the included NPZ data losslessly into JSON. `work/build.py` combines these into one standalone HTML.

`work/reference.py` calls the upstream Python code, with the documented corrected formula for unknown concentration. `work/test-core.cjs` compares those references to JavaScript. Generated reference cases and test results are included.

## Optional browser tests

Install Playwright via `npm install playwright`, and install Microsoft Edge. Then run `node work/test-browser.cjs`. Alternatively set PLAYWRIGHT_PATH to a Playwright package directory. The script uses Edge headless, local file URLs, and an offline browser context. It writes screenshots and test output into work/.

The included uploaded-gui-reference.py is the user's modified Qt GUI, preserved as migration reference. The upstream folder contains only files needed for the reference calculations and their license; it is not an installable copy of the entire upstream project.

See outputs/使用说明.md for behavior differences and validation limits. Source provenance and SHA-256 digests are in work/provenance.json.
